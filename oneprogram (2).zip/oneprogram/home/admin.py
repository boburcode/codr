from django.contrib import admin
from home.models import Setting, ContactMessage, SettingLang, Language


# Register your models here.


class SettingAdmin(admin.ModelAdmin):
    list_display = ['title']


class ContactMessageAdmin(admin.ModelAdmin):
    list_display = ['name', 'subject', 'note', 'status']
    readonly_fields = ['name', 'subject', 'phone', 'message', 'ip']
    list_filter = ['status']


class LanguagesAdmin(admin.ModelAdmin):
    list_display = ['name', 'code',  'status']
    list_filter = ['status']


class SettingLangAdmin(admin.ModelAdmin):
    list_display = ['title', 'keywords',  'description', 'lang']
    list_filter = ['lang']


admin.site.register(Setting, SettingAdmin)
admin.site.register(ContactMessage, ContactMessageAdmin)
admin.site.register(SettingLang, SettingLangAdmin)
admin.site.register(Language, LanguagesAdmin)