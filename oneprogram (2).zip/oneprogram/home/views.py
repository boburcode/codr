import requests
from ckeditor_uploader.fields import RichTextUploadingField
from django.shortcuts import render
from django.contrib import messages
# Create your views here

from django.http import HttpResponse, HttpResponseRedirect

import course
from course.models import Course, Subject, Student, Tutor, SubjectLang, TutorLang, Feedback, CourseLang
from home.models import Setting, ContactForm, SettingLang, ContactMessage
from django.conf import settings
from django.utils import translation


def index(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            name = request.POST['name']
            phone = request.POST['phone']
            subject = request.POST['subject']
            message_text = f'New message from:  \n\n Name: {name}\n Phone number: ({phone}) \n Subject: {subject}'
            telegram_api_url = f'https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage'
            telegram_params = {'chat_id': TELEGRAM_CHAT, 'text': message_text}
            requests.post(telegram_api_url, params=telegram_params)
            messages.success(request, 'Thanks,' + name + 'We recived your email and will respond you soon..')
            return HttpResponseRedirect('/')
    setting = Setting.objects.get(pk=1)
    course = Course.objects.all()
    course_cr = Course.objects.all().order_by('id')[:4]
    subject_cr = Subject.objects.all().order_by('id')[:3]
    feedback = Feedback.objects.all().order_by('id')
    defaultlang = settings.LANGUAGE_CODE[0:2]
    currentlang = request.LANGUAGE_CODE[0:2]

    if defaultlang !=currentlang:
        setting = SettingLang.objects.get(lang=currentlang)
        subject_cr = SubjectLang.objects.filter(lang=currentlang).order_by('subject__id')
        course_cr = CourseLang.objects.filter(lang=currentlang).order_by('id')
        tutor_cr = TutorLang.objects.filter(lang=currentlang).order_by('id')

    tutor_cr = Tutor.objects.all().order_by('id')[:3]

    page = 'home'
    context={'setting': setting,
             'page': page,
             'subject_cr': subject_cr,
             'course_cr': course_cr,
             'course': course,
             'tutor_cr': tutor_cr,
             'feedback': feedback}
    # return HttpResponse("Hello Django")
    return render(request, 'index.html', context)


def about(request):
    defaultlang = settings.LANGUAGE_CODE[0:2]
    currentlang = request.LANGUAGE_CODE[0:2]
    setting = Setting.objects.get(pk=1)
    subject_cr = Subject.objects.all().order_by('id')
    if defaultlang != currentlang:
        setting = SettingLang.objects.get(lang=currentlang)
        subject_cr = SubjectLang.objects.filter(lang=currentlang).order_by('subject__id')
    context = {'setting': setting,
               'subject_cr': subject_cr}
    aboutus = RichTextUploadingField(null=False, unique=True)
    contact = RichTextUploadingField(null=False, unique=True)
    return render(request, 'about.html', context)



def tutors(request):
    tutor_cr = Tutor.objects.all().order_by('id')
    subject_cr = Subject.objects.all().order_by('id')
    defaultlang = settings.LANGUAGE_CODE[0:2]
    currentlang = request.LANGUAGE_CODE[0:2]
    if defaultlang != currentlang:
        setting = SettingLang.objects.get(lang=currentlang)
        tutor_cr = TutorLang.objects.filter(lang=currentlang)
    setting = Setting.objects.get(pk=1)
    if defaultlang != currentlang:
        setting = SettingLang.objects.get(lang=currentlang)

    context = {'subject_cr': subject_cr,
               'tutor_cr': tutor_cr,
               'setting': setting}
    return render(request, 'tutors.html', context)


def student(request):
    defaultlang = settings.LANGUAGE_CODE[0:2]
    currentlang = request.LANGUAGE_CODE[0:2]
    if defaultlang != currentlang:
        setting = SettingLang.objects.get(lang=currentlang)
        student_cr = Tutor.objects.filter(tutorlang__lang=currentlang).order_by('id')[:3]
    student_cr = Student.objects.all().order_by('id')
    setting = Setting.objects.get(pk=1)

    context = {'student_cr': student_cr, 'setting': setting}
    return render(request, 'student.html', context)


def subject_detail(request, id, slug):
    defaultlang = settings.LANGUAGE_CODE[0:2]
    currentlang = request.LANGUAGE_CODE[0:2]
    course = Course.objects.all()
    subject = Subject.objects.get(pk=id)

    if defaultlang != currentlang:
        try:
            prolang = SubjectLang.objects.get(subject=subject, lang=currentlang)
            subject.title = prolang.title
            subject.description = prolang.description
            subject.keywords = prolang.keywords
            subject.detail = prolang.detail
        except SubjectLang.DoesNotExist:
            pass
    subject_cr = Subject.objects.all().order_by('id')[:4]
    course = Course.objects.all()
    subject = Subject.objects.get(pk=id)

    context = {'subject': subject,
                'course': course,
                'subject_cr': subject_cr}
    return render(request, 'subject_detail.html', context)


def selectlanguage(request):

    if request.method == 'POST':
        cur_language = translation.get_language()
        lasturl = request.META.get('HTTP_REFERER')
        lang = request.POST['language']
        translation.activate(lang)
        request.session[settings.LANGUAGE_COOKIE_NAME] = lang
        return HttpResponseRedirect("/" + lang)


def subject(request):
    # tutor_cr = Tutor.objects.all().order_by('id')
    subject_cr = Subject.objects.all().order_by('id')
    defaultlang = settings.LANGUAGE_CODE[0:2]
    currentlang = request.LANGUAGE_CODE[0:2]
    if defaultlang != currentlang:
        setting = SettingLang.objects.get(lang=currentlang)
        subject_cr = SubjectLang.objects.filter(lang=currentlang).order_by('subject__id')
    setting = Setting.objects.get(pk=1)
    if defaultlang != currentlang:
        setting = SettingLang.objects.get(lang=currentlang)

    context = {'subject_cr': subject_cr, 'setting': setting}
    return render(request, 'subject.html', context)


TELEGRAM_BOT_TOKEN = '6287356889:AAFSMWamLhtFOFjLg2VKyuc61_ETUtzBdN4'
TELEGRAM_CHAT = '1365675028'


def contact(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            name = request.POST['name']
            phone = request.POST['phone']
            message = request.POST['message']
            subject = request.POST['subject']
            email = request.POST['email']
            message_text = f'New message from: {name}\n Phone number: ({phone}): \n Email: {email}  Subject: {subject}\n\n{message}'
            telegram_api_url = f'https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage'
            telegram_params = {'chat_id': TELEGRAM_CHAT, 'text': message_text}
            requests.post(telegram_api_url, params=telegram_params)
            messages.success(request, 'Thanks,' + name + 'We recived your email and will respond you soon..')
    defaultlang = settings.LANGUAGE_CODE[0:2]
    currentlang = request.LANGUAGE_CODE[0:2]
    setting = Setting.objects.get(pk=1)
    if defaultlang != currentlang:
        setting = SettingLang.objects.get(lang=currentlang)
    form = ContactForm()
    subject_cr = Subject.objects.all().order_by('id')[:4]
    page = 'home'

    context = {'setting': setting,
               'form': form,
               'page': page,
               'subject_cr': subject_cr,
               }
    # return HttpResponse("Contact page")
    return render(request, 'contact.html', context)


