from django.shortcuts import render
from django.http import HttpResponse
import requests
from django.conf import settings
from course.models import Subject
from home.models import ContactForm, SettingLang, Setting

# Create your views here.


TELEGRAM_BOT_TOKEN = '6287356889:AAFSMWamLhtFOFjLg2VKyuc61_ETUtzBdN4'
TELEGRAM_CHAT = '1365675028'


def index(request):
    # if request.method == 'POST':
    #     form = ContactForm(request.POST)
    #     if form.is_valid():
    #         name = request.POST['name']
    #         phone = request.POST['phone']
    #         email = request.POST['email']
    #         message = ['message']
    #         subject = ['subject']
    #         message_text = f'New message from: {name}\n Phone number: ({phone}) \n Email: {email} '
    #         telegram_api_url = f'https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage'
    #         telegram_params = {'chat_id': TELEGRAM_CHAT, 'text': message_text}
    #         requests.post(telegram_api_url, params=telegram_params)
    # defaultlang = settings.LANGUAGE_CODE[0:2]
    # currentlang = request.LANGUAGE_CODE[0:2]
    # setting = Setting.objects.get(pk=1)
    # if defaultlang != currentlang:
    #     setting = SettingLang.objects.get(lang=currentlang)
    # form = ContactForm()
    # subject_cr = Subject.objects.all().order_by('id')[:4]
    # page = 'home'
    #
    # context = {'setting': setting,
    #            'form': form,
    #            'page': page,
    #            'subject_cr': subject_cr,
    #            }
    # return HttpResponse("Page with courses")
    return render(request, 'index.html')
