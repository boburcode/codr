
from django.db import models
from ckeditor_uploader.fields import RichTextUploadingField
from django.utils.safestring import mark_safe

import course
from django.urls import reverse
from home.models import Language

llist = Language.objects.all()
list1 = []
for rs in llist:
    list1.append((rs.code, rs.name))
langlist = (list1)
# Create your models here.


class Course(models.Model):
    title = models.CharField(max_length=30)
    keywords = models.CharField(max_length=255)
    description = RichTextUploadingField(null=False, unique=True)
    image = models.ImageField(blank=True, upload_to='images/')
    slug = models.SlugField(null=False, unique=True)

    def __str__(self):
        return self.title

    def image_tag(self):
        return mark_safe('<img src="{}" height="50"/>'.format(self.image.url))
    image_tag.short_description = 'image'


class Subject(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    title = models.CharField(max_length=255)
    level = models.CharField(max_length=255)
    time = models.CharField(max_length=255)
    subject_tutor = RichTextUploadingField(null=False, unique=True)
    description = RichTextUploadingField(null=False, unique=True)
    image = models.ImageField(upload_to='images/')
    price = models.CharField(max_length=50)
    detail = models.CharField(max_length=255)
    slug = models.SlugField(null=False, unique=True)

    def __str__(self):
        return self.title

    def image_tag(self):
        return mark_safe('<img src="{}" height="50"/>'.format(self.image.url))
    image_tag.short_description = 'image'


class Student(models.Model):
    name = models.CharField(max_length=150)
    description = models.CharField(max_length=255)
    image = models.ImageField(upload_to='images/')

    def __str__(self):
        return self.name

    def image_tag(self):
        return mark_safe('<img src="{}" height="50"/>'.format(self.image.url))
    image_tag.short_description = 'image'


class Tutor(models.Model):
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    lang = models.CharField(max_length=6, choices=langlist, default='')
    name = models.CharField(max_length=255)
    description = models.CharField(max_length=255)
    image = models.ImageField(upload_to='images/')
    facebook = models.CharField(blank=True, max_length=50)
    instagram = models.CharField(blank=True, max_length=50)
    create_at = models.DateTimeField(auto_now_add=True)
    update_at = models.DateTimeField(auto_now=True)
    slug = models.SlugField(default="default-slug")

    def __str__(self):
        return self.name

    def image_tag(self):
        return mark_safe('<img src="{}" height="50"/>'.format(self.image.url))
    image_tag.short_description = 'image'


llist = Language.objects.all()
list1 = []
for rs in llist:
    list1.append((rs.code, rs.name))
langlist = (list1)


class SubjectLang(models.Model):
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    lang = models.CharField(max_length=6, choices=langlist)
    title = models.CharField(max_length=255)
    level = models.CharField(max_length=255)
    time = models.CharField(max_length=255)
    subject_tutor = RichTextUploadingField(null=False, unique=True, default='')
    price = models.CharField(max_length=50, default='')
    description = models.CharField(max_length=255, default='')
    keywords = models.CharField(max_length=255, default='')
    detail = RichTextUploadingField()
    slug = models.SlugField(null=False, unique=True)

    def get_absolute_url(self):
        return reverse('subject_detail', kwargs={'slug': self.slug})


class CourseLang(models.Model):
    course = models.ForeignKey(Course, related_name='course_lang', on_delete=models.CASCADE)
    lang = models.CharField(max_length=6, choices=langlist)
    title = models.CharField(max_length=30)
    keywords = models.CharField(max_length=255)
    description = RichTextUploadingField(null=False, unique=True)
    slug = models.SlugField(null=False, unique=True)

    def get_absolute_url(self):
        return reverse('course_detail', kwargs={'slug': self.slug})


class TutorLang(models.Model):
    tutor = models.ForeignKey(Tutor, on_delete=models.CASCADE)
    lang = models.CharField(max_length=6, choices=langlist)
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    description = models.CharField(max_length=255)
    create_at = models.DateTimeField(auto_now_add=True)
    update_at = models.DateTimeField(auto_now=True)
    slug = models.SlugField(null=False, unique=True)
    detail = RichTextUploadingField(default='')

    def get_absolute_url(self):
        return reverse('tutors', kwargs={'slug': self.slug})


class Student(models.Model):
    name = models.CharField(max_length=150)
    description = models.CharField(max_length=255)
    image = models.ImageField(upload_to='images/')


class Feedback(models.Model):
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    feedback = models.CharField(max_length=255)
    feedback_long = RichTextUploadingField(blank=True)
    image = models.ImageField(upload_to='images/')
    tutor = models.ForeignKey(Tutor, on_delete=models.CASCADE)


    def __str__(self):
        return self.feedback
    def image_tag(self):
        return mark_safe('<img src="{}" height="50"/>'.format(self.image.url))
    image_tag.short_description = 'image'

class FeedbackLang(models.Model):
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    lang = models.CharField(max_length=6, choices=langlist)
    feedback = RichTextUploadingField(blank=True)
    tutor = models.ForeignKey(Tutor, on_delete=models.CASCADE)

    def __str__(self):
        return self.feedback

