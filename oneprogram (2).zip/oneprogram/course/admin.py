from django.contrib import admin

# Register your models here.


from course.models import Subject, Tutor, Student, Course, CourseLang, SubjectLang, TutorLang, FeedbackLang, Feedback


class CourseAdmin(admin.ModelAdmin):
    list_display = ['title', 'slug']


class SubjectAdmin(admin.ModelAdmin):
    list_display = ['title', 'course', 'slug']
    list_filter = ['course']
    readonly_fields = ('image_tag',)


class StudentAdmin(admin.ModelAdmin):
    list_display = ['name', 'description']


class TutorAdmin(admin.ModelAdmin):
    list_display = ['name', 'description']
    list_filter = ['subject']


class CourseLangInline(admin.TabularInline):
    model = CourseLang
    extra = 1
    show_change_link = True
    prepopulated_fields = {'slug': ('title',)}


class SubjectLangInline(admin.TabularInline):
    model = SubjectLang
    extra = 1
    show_change_link = True
    prepopulated_fields = {'slug': ('title',)}

    # return self.get_urls(model)


class TutorLangInline(admin.TabularInline):
    model = TutorLang
    extra = 1
    show_change_link = True
    prepopulated_fields = {'slug': ('title',)}


class SubjectLanguageAdmin(admin.ModelAdmin):
    list_display = ['keywords', 'lang', 'slug']
    prepopulated_fields = {'slug': ('keywords',)}
    list_filter = ['lang']


class CourseLanguageAdmin(admin.ModelAdmin):
    list_display = ['keywords', 'lang', 'slug']
    prepopulated_fields = {'slug': ('keywords',)}
    list_filter = ['lang']


class TutorLanguageAdmin(admin.ModelAdmin):
    list_display = ['name', 'lang', 'slug']
    prepopulated_fields = {'slug': ('name',)}
    list_filter = ['lang']


class FeedbackAdmin(admin.ModelAdmin):
    list_display = ['subject', 'image_tag']


class FeedbackLanguageAdmin(admin.ModelAdmin):
    list_display = ['subject']


admin.site.register(Course, CourseAdmin)
admin.site.register(Subject, SubjectAdmin)
admin.site.register(Tutor, TutorAdmin)
admin.site.register(Student, StudentAdmin)
admin.site.register(SubjectLang, SubjectLanguageAdmin)
admin.site.register(TutorLang, TutorLanguageAdmin)
admin.site.register(CourseLang, CourseLanguageAdmin)
admin.site.register(Feedback, FeedbackAdmin)
admin.site.register(FeedbackLang, FeedbackLanguageAdmin)






