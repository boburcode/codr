"""
URL configuration for oneprogram project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf.urls.static import static, settings

from home import views
from django.conf.urls.i18n import i18n_patterns
from django.utils.translation import gettext_lazy as _

urlpatterns = [
    path('selectlanguage', views.selectlanguage, name='selectlanguage'),
    path('i18n/', include('django.conf.urls.i18n')),
]

urlpatterns += i18n_patterns(
    path(_('admin/'), admin.site.urls),
    path('home/', include('home.urls')),
    path('', views.index, name='home'),
    path('course/', include('course.urls')),
    path('ckeditor/', include('ckeditor_uploader.urls')),
    path('about/', views.about, name='about'),
    path('contact/', views.contact, name='contact'),
    path('tutors/', views.tutors, name='tutors'),
    path('subjects/', views.subject, name='subject'),
    path('student/', views.student, name='student'),
    path('subject/<int:id>/<slug:slug>', views.subject_detail, name='subject_detail'),

    prefix_default_language=False,

) + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

